/* Copyright 1993, 2012 by Michael R. Clements
 * This software is open source and free to distribute and create derivative works.
 * But this notice of copyright and author must be retained.
*/
package com.mrc.caterpillar;

import java.io.IOException;

import android.graphics.*;
import android.content.res.*;

/* This class represents the yummy Apple that hungry Caterpillars like to eat.
 * It appears at a random location, lives for a random length of time,
 * and when eaten it grows the Caterpillar a random amount.
 * As it sits on the screen, it goes "stale" and has less "energy",
 * so the sooner it is eaten the more the Caterpillar grows.
*/
public class TargetApple {
	protected static final int	MAX_POINTS	= 10;
	protected static Bitmap		ourImgDefault;
	protected static Sound		soundApple;
	protected static int		lifespan	= 0;

	// WARNING: you must call this before you instantiate the class
	static public void initResources(AssetManager am) throws IOException {
		if(ourImgDefault == null) {
			ourImgDefault = Util.getBitmap("apple.png", am);
			soundApple = new Sound("apple.mp3", (float)1.0, am);
		}
	}

	public static void adjustResources() {
		ourImgDefault = Util.resizeBitmap(ourImgDefault,
				CaterpillarMain.gameCfg.SEG_SIZE);
	}

	public static void freeResources() {
		if(ourImgDefault != null) {
			ourImgDefault.recycle();
			ourImgDefault = null;
			soundApple.close();
			soundApple = null;
		}
	}

	Point		pos;
	boolean		alive;
	int			points;
	Bitmap		img;
	GameConfig	gameCfg;

	public TargetApple(Point _pos) {
		init(_pos, 0, null);
	}

	public void init(Point _pos, int _points, Bitmap _img) {
		soundApple.play();
		// get the global game config
		gameCfg = CaterpillarMain.gameCfg;
		alive = true;
		pos = _pos;
		points = (_points > 0 ? _points : (int)(Math.random() * MAX_POINTS));
		img = (_img != null ? _img : ourImgDefault);
	}

	// ages the target (randomly drops the score) - returns FALSE if dead
	public boolean stillAlive() {
		if(alive && shouldAge()) {
			points--;
			if(points <= 0)
				alive = false;
		}
		return alive;
	}

	public void eat() {
		alive = false;
	}

	public void draw(Canvas cvs) {
		cvs.drawBitmap(img, pos.x, pos.y, null);
	}

	// returns TRUE if the target should age (reduce score)
	protected boolean shouldAge() {
		return((int)(Math.random() * getLifespan()) == 0);
	}

	// target lifespan is proportional to the area of the board
	// (this makes probability of reaching it roughly constant independent of
	// board size)
	protected int getLifespan() {
		if(lifespan != 0)
			return lifespan;
		lifespan = (int)(gameCfg.XCELLS * gameCfg.YCELLS * 0.008 + 0.5);
		return lifespan;
	}
}
